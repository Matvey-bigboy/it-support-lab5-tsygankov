set -euo pipefail
echo 'LAB5: configure PostgreSQL, Zabbix, Nginx and classic server agent'
date -Is
systemctl start postgresql
pg_lsclusters
pg_isready
python3 - <<'PY'
from pathlib import Path
import secrets,subprocess,re
private=Path('/root/matvey-lab5');private.mkdir(mode=0o700,exist_ok=True)
check=subprocess.check_output(['runuser','-u','postgres','--','psql','-Atqc',"SELECT 1 FROM pg_roles WHERE rolname='zabbix'"]).decode().strip()
if check:raise SystemExit('Guard: database role already exists; do not reinitialize it')
password=secrets.token_hex(24)
p=private/'db.password';p.write_text(password);p.chmod(0o600)
sql="CREATE ROLE zabbix LOGIN PASSWORD '"+password+"';\nCREATE DATABASE zabbix OWNER zabbix ENCODING 'UTF8';\n"
subprocess.run(['runuser','-u','postgres','--','psql','-v','ON_ERROR_STOP=1'],input=sql.encode(),check=True)
def update(path,values):
    p=Path(path);text=p.read_text()
    backup=private/(p.name+'.before')
    if not backup.exists():backup.write_text(text);backup.chmod(0o600)
    for key,value in values.items():
        text=re.sub(r'^'+re.escape(key)+r'=.*$', '',text,flags=re.M)
        text+='\n'+key+'='+value+'\n'
    p.write_text(text)
update('/etc/zabbix/zabbix_server.conf',{'DBHost':'localhost','DBName':'zabbix','DBUser':'zabbix','DBPassword':password,'ListenIP':'127.0.0.1,172.27.25.1','CacheSize':'64M','Timeout':'10'})
update('/etc/zabbix/zabbix_agentd.conf',{'Server':'127.0.0.1,172.27.25.1','ServerActive':'172.27.25.1','Hostname':'matvey-zabbix-server','ListenIP':'127.0.0.1,172.27.25.1','Timeout':'10'})
php="""<?php
$DB['TYPE'] = 'POSTGRESQL';
$DB['SERVER'] = 'localhost';
$DB['PORT'] = '5432';
$DB['DATABASE'] = 'zabbix';
$DB['USER'] = 'zabbix';
$DB['PASSWORD'] = '%s';
$DB['SCHEMA'] = '';
$ZBX_SERVER = '127.0.0.1';
$ZBX_SERVER_PORT = '10051';
$ZBX_SERVER_NAME = 'Matvey Lab 5 ISP-34';
$IMAGE_FORMAT_DEFAULT = IMAGE_FORMAT_PNG;
""" % password
p=Path('/etc/zabbix/web/zabbix.conf.php');p.write_text(php);p.chmod(0o640)
subprocess.run(['chown','root:www-data',str(p)],check=True)
p=Path('/etc/zabbix/php-fpm.conf');text=p.read_text();text+='\nphp_value[date.timezone] = Asia/Novosibirsk\n';p.write_text(text)
PY
zcat /usr/share/zabbix-sql-scripts/postgresql/server.sql.gz | runuser -u zabbix -- psql -v ON_ERROR_STOP=1 zabbix > /root/matvey-lab5/schema-import.log
runuser -u postgres -- psql -d zabbix -Atc "SELECT count(*) AS public_tables FROM information_schema.tables WHERE table_schema='public';"
hostnamectl set-hostname matvey-zabbix-server
sed -i 's/127\.0\.1\.1[[:space:]].*/127.0.1.1 matvey-zabbix-server/' /etc/hosts
cp -a /etc/zabbix/nginx.conf /root/matvey-lab5/nginx.conf.before
cat > /etc/zabbix/nginx.conf <<'NGINX'
server {
    listen 80 default_server;
    server_name _;
    root /usr/share;
    index index.php;
    location = / { return 302 /zabbix/; }
    location = /zabbix { return 302 /zabbix/; }
    location / { return 404; }
    location /zabbix/ { try_files $uri $uri/ =404; }
    location /zabbix/assets/ { access_log off; expires 10d; }
    location ~ /\.ht { deny all; }
    location ~ ^/zabbix/(api/|conf[^.]|include|locale|vendor) { deny all; return 404; }
    location ~ ^/zabbix/.*\.php(/|$) {
        try_files $uri =404;
        fastcgi_pass unix:/var/run/php/zabbix.sock;
        fastcgi_split_path_info ^(.+\.php)(/.+)$;
        fastcgi_index index.php;
        include fastcgi_params;
        fastcgi_param SCRIPT_FILENAME /usr/share$fastcgi_script_name;
        fastcgi_param DOCUMENT_ROOT /usr/share;
        fastcgi_read_timeout 180;
        fastcgi_buffer_size 128k;
        fastcgi_buffers 4 256k;
        fastcgi_busy_buffers_size 256k;
    }
}
NGINX
if test -L /etc/nginx/sites-enabled/default; then unlink /etc/nginx/sites-enabled/default; fi
nginx -t
php -l /etc/zabbix/web/zabbix.conf.php
systemctl enable postgresql zabbix-server zabbix-agent nginx php8.4-fpm
systemctl restart php8.4-fpm nginx zabbix-server zabbix-agent
echo 'SERVICE STATUS'
systemctl is-active postgresql@17-main zabbix-server zabbix-agent nginx php8.4-fpm
systemctl is-enabled zabbix-server zabbix-agent nginx php8.4-fpm
echo 'LISTENING PORTS'
ss -lntp | grep -E ':(80|5432|10050|10051) '
echo 'AGENT RESPONSE'
zabbix_get -s 172.27.25.1 -k agent.ping
zabbix_get -s 172.27.25.1 -k agent.version
echo 'HTTP CHECK'
curl -s -o /dev/null -w 'HTTP %{http_code}\n' http://172.27.25.1/zabbix/
echo 'ZABBIX VERSION'
zabbix_server -V | head -3
date -Is
