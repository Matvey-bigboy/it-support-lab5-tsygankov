#!/bin/bash
# Read-only final validation. No service or configuration mutations.
set -euo pipefail
python3 - <<'PY'
import subprocess, json, datetime

def command(args):
    p = subprocess.run(args, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return {'rc':p.returncode, 'stdout':p.stdout.strip(), 'stderr':p.stderr.strip()}

def sql(statement):
    wrapped = 'BEGIN READ ONLY; ' + statement.rstrip(';') + '; COMMIT;'
    result = command(['runuser','-u','postgres','--','psql','-X','-q','-t','-A','-v','ON_ERROR_STOP=1','-d','zabbix','-c',wrapped])
    if result['rc']:
        raise RuntimeError(result)
    return json.loads(result['stdout']) if result['stdout'] else None

def latest(item):
    table = {0:'history',1:'history_str',3:'history_uint',4:'history_text'}.get(item['value_type'])
    if not table:
        return {'unsupported_value_type':item['value_type']}
    itemid = int(item['itemid'])
    return sql(f"SELECT row_to_json(q) FROM (SELECT clock,to_char(to_timestamp(clock) AT TIME ZONE 'UTC','YYYY-MM-DD\"T\"HH24:MI:SS\"Z\"') AS utc, extract(epoch FROM now())::bigint-clock AS age_seconds,value::text AS value FROM {table} WHERE itemid={itemid} ORDER BY clock DESC,ns DESC LIMIT 1) q")

result = {'read_only':True,'collector_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
result['identity'] = command(['hostnamectl','--static'])
result['os'] = command(['cat','/etc/os-release'])
result['addresses'] = command(['ip','-br','-4','address'])
result['database_clock'] = sql("SELECT json_build_object('epoch',extract(epoch FROM now())::bigint,'utc',to_char(now() AT TIME ZONE 'UTC','YYYY-MM-DD\"T\"HH24:MI:SS\"Z\"'),'database',current_database(),'version',version())")
services = ['zabbix-server','zabbix-agent','nginx','php8.4-fpm','postgresql','postgresql@17-main']
result['services'] = {name:command(['systemctl','show','-p','Id','-p','ActiveState','-p','SubState','-p','UnitFileState',name]) for name in services}
result['postgres_ready'] = command(['pg_isready'])
result['postgres_clusters'] = command(['pg_lsclusters'])
result['package_versions'] = command(['dpkg-query','-W','-f=${Package}\t${Version}\n','zabbix-server-pgsql','zabbix-agent','zabbix-get','postgresql-17','nginx','php8.4-fpm'])
result['agent_queries'] = {ip:{key:command(['zabbix_get','-s',ip,'-k',key]) for key in ['agent.ping','agent.hostname','agent.version','system.hostname','system.uptime','vm.memory.size[available]']} for ip in ['172.27.25.1','172.27.25.2']}
result['server_to_arm_ping'] = command(['ping','-c','4','-W','2','172.27.25.2'])
result['frontend_http'] = command(['curl','-s','-o','/dev/null','-w','%{http_code}','http://172.27.25.1/zabbix/'])
result['hosts'] = sql("SELECT coalesce(json_agg(q),'[]') FROM (SELECT hostid::text,host,name,status FROM hosts WHERE hostid IN (10084,10683) ORDER BY hostid) q")
result['templates'] = sql("SELECT coalesce(json_agg(q),'[]') FROM (SELECT ht.hostid::text,t.hostid::text AS templateid,t.host AS template FROM hosts_templates ht JOIN hosts t ON t.hostid=ht.templateid WHERE ht.hostid IN (10084,10683) ORDER BY ht.hostid,t.host) q")
result['interfaces'] = sql("SELECT coalesce(json_agg(q),'[]') FROM (SELECT interfaceid::text,hostid::text,main,type,useip,ip,dns,port,available,error FROM interface WHERE hostid IN (10084,10683) ORDER BY hostid,interfaceid) q")
result['items'] = sql("SELECT coalesce(json_agg(q),'[]') FROM (SELECT itemid::text,hostid::text,name,key_,value_type,status,delay FROM items WHERE hostid IN (10084,10683) AND key_ IN ('agent.version','system.uptime','vm.memory.size[available]','vm.memory.size[pavailable]','vm.memory.utilization') ORDER BY hostid,key_) q")
for item in result['items']:
    item['latest'] = latest(item)
result['arm_open_problems'] = sql("SELECT coalesce(json_agg(q),'[]') FROM (SELECT DISTINCT p.eventid::text,p.name,p.severity,p.clock,to_char(to_timestamp(p.clock) AT TIME ZONE 'UTC','YYYY-MM-DD\"T\"HH24:MI:SS\"Z\"') AS utc,p.objectid::text AS triggerid,t.expression,t.recovery_expression FROM problem p JOIN triggers t ON t.triggerid=p.objectid JOIN functions f ON f.triggerid=t.triggerid JOIN items i ON i.itemid=f.itemid WHERE i.hostid=10683 AND p.r_eventid IS NULL AND p.source=0 AND p.object=0 ORDER BY p.clock) q")
for problem in result['arm_open_problems']:
    triggerid = int(problem['triggerid'])
    problem['items'] = sql(f"SELECT coalesce(json_agg(q),'[]') FROM (SELECT DISTINCT i.itemid::text,i.hostid::text,i.name,i.key_,i.value_type,i.status FROM functions f JOIN items i ON i.itemid=f.itemid WHERE f.triggerid={triggerid}) q")
    for item in problem['items']:
        item['latest'] = latest(item)
result['captured_utc_end'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
print(json.dumps(result,ensure_ascii=False,indent=2))
PY
