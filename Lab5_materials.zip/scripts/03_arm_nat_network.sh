set -euo pipefail
test "$(cat /sys/class/net/enp0s3/address)" = '08:00:27:25:34:02'
test "$(cat /sys/class/net/enp0s8/address)" = '08:00:27:25:35:02'
ip -4 address show enp0s3 | grep -q '172.27.25.2/24'
systemctl is-active --quiet systemd-networkd
printf 'EXISTING BRIDGE CONFIG HASH BEFORE\n'
sha256sum /etc/netplan/50-cloud-init.yaml
if test -e /etc/netplan/60-lab5-nat.yaml; then
  echo 'Lab5 NAT file already exists; refusing overwrite' >&2; exit 4
fi
install -m 600 /dev/null /etc/netplan/60-lab5-nat.yaml
cat > /etc/netplan/60-lab5-nat.yaml <<'EOF'
network:
  version: 2
  renderer: networkd
  ethernets:
    lab5nat:
      match:
        macaddress: 08:00:27:25:35:02
      set-name: enp0s8
      dhcp4: true
      dhcp6: false
      optional: true
      dhcp4-overrides:
        route-metric: 200
        use-dns: true
EOF
netplan generate
networkctl reload
networkctl reconfigure enp0s8
for attempt in $(seq 1 20); do
  if ip -4 route show default | grep -q 'dev enp0s8'; then break;fi
  sleep 1
done
ip -4 route show default | grep 'dev enp0s8'
printf '\nADDRESSES\n'
ip -br -4 address
printf '\nROUTES\n'
ip route
printf '\nDNS\n'
resolvectl status enp0s8
resolvectl query repo.zabbix.com
printf '\nTLS VERIFIED OFFICIAL REPOSITORY\n'
python3 - <<'PY'
import urllib.request
url='https://repo.zabbix.com/zabbix/7.0/debian/pool/main/z/zabbix-release/zabbix-release_latest_7.0+debian13_all.deb'
with urllib.request.urlopen(url,timeout=30) as response:
    print('HTTPS status:',response.status)
    print('Content-Type:',response.headers.get('Content-Type'))
PY
printf '\nBRIDGE CONFIG HASH AFTER\n'
sha256sum /etc/netplan/50-cloud-init.yaml
ping -c 4 -W 2 172.27.25.1
