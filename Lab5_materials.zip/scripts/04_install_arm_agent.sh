set -euo pipefail
test "$(id -u)" = 0
ip -4 address show enp0s3 | grep -q '172.27.25.2/24'
export DEBIAN_FRONTEND=noninteractive
printf 'OFFICIAL RELEASE PACKAGE\n'
python3 - <<'PY'
import urllib.request,pathlib,hashlib
url='https://repo.zabbix.com/zabbix/7.0/debian/pool/main/z/zabbix-release/zabbix-release_latest_7.0+debian13_all.deb'
dest=pathlib.Path('/var/tmp/zabbix-release_latest_7.0+debian13_all.deb')
with urllib.request.urlopen(url,timeout=45) as response:
    data=response.read()
dest.write_bytes(data)
print(dest.name,len(data),'bytes','SHA256',hashlib.sha256(data).hexdigest())
PY
test "$(dpkg-deb -f /var/tmp/zabbix-release_latest_7.0+debian13_all.deb Package)" = zabbix-release
dpkg-deb -f /var/tmp/zabbix-release_latest_7.0+debian13_all.deb Package Version Architecture
dpkg -i /var/tmp/zabbix-release_latest_7.0+debian13_all.deb
printf '\nSIGNED REPOSITORY UPDATE\n'
apt-get update
printf '\nAGENT PACKAGE POLICY\n'
apt-cache policy zabbix-agent
apt-get install -y --no-install-recommends zabbix-agent
printf '\nVERSION\n'
zabbix_agentd --version
printf '\nINSTALLED PACKAGE\n'
dpkg-query -W -f='${Package}\t${Version}\t${Status}\n' zabbix-agent
printf '\nOFFICIAL REPOSITORY FILES\n'
find /etc/apt/sources.list.d -maxdepth 1 -type f -name '*zabbix*' -exec cat {} \;
