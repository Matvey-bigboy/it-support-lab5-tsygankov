#!/bin/bash
# Read-only workstation validation, without service changes.
set -euo pipefail
python3 - <<'PY'
import subprocess,json,datetime
def command(args):
    p=subprocess.run(args,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    return {'rc':p.returncode,'stdout':p.stdout.strip(),'stderr':p.stderr.strip()}
r={'read_only':True,'collector_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
r['identity']=command(['hostnamectl','--static'])
r['os']=command(['cat','/etc/os-release'])
r['addresses']=command(['ip','-br','-4','address'])
r['zabbix_agent_service']=command(['systemctl','show','-p','Id','-p','ActiveState','-p','SubState','-p','UnitFileState','zabbix-agent'])
r['version']=command(['dpkg-query','-W','-f=${Package}\t${Version}\n','zabbix-agent'])
r['agent_config_public']=command(['grep','-E','^(Server|ServerActive|Hostname|ListenIP|ListenPort)=','/etc/zabbix/zabbix_agentd.conf'])
r['listener']=command(['ss','-lnt','sport = :10050'])
r['arm_to_server_ping']=command(['ping','-c','4','-W','2','172.27.25.1'])
r['agent_test_uptime']=command(['zabbix_agentd','-t','system.uptime','-c','/etc/zabbix/zabbix_agentd.conf'])
print(json.dumps(r,ensure_ascii=False,indent=2))
PY
