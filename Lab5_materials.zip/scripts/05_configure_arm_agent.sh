set -euo pipefail
test "$(id -u)" = 0
dpkg-query -W -f='${Status}' zabbix-agent | grep -qx 'install ok installed'
ip -4 address show enp0s3 | grep -q '172.27.25.2/24'
if ! test -e /etc/zabbix/zabbix_agentd.conf.before_lab5; then
  cp -a /etc/zabbix/zabbix_agentd.conf /etc/zabbix/zabbix_agentd.conf.before_lab5
fi
cat > /etc/zabbix/zabbix_agentd.conf <<'EOF'
# Matvey Lab 5: classic passive and active agent on the isolated monitoring link.
PidFile=/run/zabbix/zabbix_agentd.pid
LogFile=/var/log/zabbix/zabbix_agentd.log
LogFileSize=1
Server=172.27.25.1
ServerActive=172.27.25.1:10051
Hostname=matvey-arm
ListenIP=172.27.25.2
ListenPort=10050
Timeout=3
Include=/etc/zabbix/zabbix_agentd.d/*.conf
EOF
chown root:root /etc/zabbix/zabbix_agentd.conf
chmod 644 /etc/zabbix/zabbix_agentd.conf
hostnamectl set-hostname matvey-arm
python3 - <<'PY'
from pathlib import Path
p=Path('/etc/hosts')
original=p.read_text()
lines=original.splitlines()
found=False
for i,line in enumerate(lines):
    if line.split()[:1]==['127.0.1.1']:
        lines[i]='127.0.1.1 matvey-arm'
        found=True
if not found: lines.append('127.0.1.1 matvey-arm')
p.write_text('\n'.join(lines)+'\n')
Path('/etc/cloud/cloud.cfg.d/99-lab5-hostname.cfg').write_text('preserve_hostname: true\n')
PY
printf 'CONFIGURATION VALIDATION\n'
zabbix_agentd -T -c /etc/zabbix/zabbix_agentd.conf
systemctl enable zabbix-agent
systemctl restart zabbix-agent
printf '\nIDENTITY AND VERSION\n'
hostname
zabbix_agentd --version
printf '\nCONFIGURATION\n'
cat /etc/zabbix/zabbix_agentd.conf
printf '\nSERVICE\n'
systemctl show -p Id -p ActiveState -p SubState -p UnitFileState zabbix-agent
printf '\nLISTENING PORT\n'
ss -lntp '( sport = :10050 )'
printf '\nLOCAL AGENT KEY CHECK\n'
sudo -u zabbix zabbix_agentd -t agent.ping -c /etc/zabbix/zabbix_agentd.conf
printf '\nADDRESSES AND ROUTES\n'
ip -br -4 address
ip route
printf '\nPING SERVER\n'
ping -c 4 -W 2 172.27.25.1
printf '\nSERVER ACTIVE CHECK PORT\n'
timeout 5 bash -c 'exec 3<>/dev/tcp/172.27.25.1/10051; echo TCP_10051_CONNECTED; exec 3<&-; exec 3>&-'
printf '\nRECENT AGENT LOG\n'
tail -n 12 /var/log/zabbix/zabbix_agentd.log
