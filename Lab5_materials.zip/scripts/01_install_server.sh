set -euo pipefail
export DEBIAN_FRONTEND=noninteractive
echo 'LAB5: native Zabbix server installation in the assigned Debian VM'
date -Is
install -d -m 700 /root/matvey-lab5
if test -f /etc/apt/sources.list; then
  test -f /root/matvey-lab5/sources.list.before || cp -a /etc/apt/sources.list /root/matvey-lab5/sources.list.before
  sed -i '/^[[:space:]]*deb .*cdrom:/s/^/# LAB5 disabled installation media: /' /etc/apt/sources.list
fi
apt-get update
apt-get install -y --no-install-recommends wget ca-certificates
wget -q 'https://repo.zabbix.com/zabbix/7.0/debian/pool/main/z/zabbix-release/zabbix-release_latest_7.0+debian13_all.deb' -O /root/matvey-lab5/zabbix-release.deb
dpkg -i /root/matvey-lab5/zabbix-release.deb
apt-get update
apt-get install -y --no-install-recommends postgresql nginx zabbix-server-pgsql zabbix-frontend-php php8.4-pgsql zabbix-nginx-conf zabbix-sql-scripts zabbix-agent zabbix-get
systemctl stop zabbix-server
echo 'INSTALLED VERSIONS'
dpkg-query -W -f='${Package} ${Version}\n' postgresql nginx php8.4-fpm php8.4-pgsql zabbix-server-pgsql zabbix-frontend-php zabbix-agent
echo 'SCHEMA FILES'
find /usr/share -maxdepth 6 -path '*zabbix*' -name '*.sql.gz' -print
echo 'NGINX CONFIG'
cat /etc/zabbix/nginx.conf
echo 'FRONTEND LOCATION'
dpkg -L zabbix-frontend-php | sed -n '1,38p'
echo 'PHP POOL'
cat /etc/zabbix/php-fpm.conf
date -Is
