# Запуск и остановка сохраненного стенда ЛР 5

Стенд состоит из двух VirtualBox VM на разных уровнях вложенности. Внешняя Debian VM `Matvey_Lab4_Debian_20261027` работает на Windows и выполняет роль Zabbix Server. Внутри нее VirtualBox запускает АРМ `Matvey_Bridge_Debian_20261027`. Имена VM сохранены от ЛР4; актуальные имена гостевых ОС - `matvey-zabbix-server` и `matvey-arm`.

Мониторинг проходит по изолированному сегменту `172.27.25.1/24 <-> 172.27.25.2/24`. У внешней VM NAT дает доступ к пакетным репозиториям; у АРМ дополнительный NAT-интерфейс `enp0s8` получает `10.0.3.15/24`. Основной интерфейс АРМ `enp0s3` использует Bridge к `enp0s8` внешней Linux VM. Адрес NAT внутри АРМ не используется как Agent interface в Zabbix.

Веб-доступ с этого Windows ПК: `http://127.0.0.1:18885/zabbix/`. Это проброс только с loopback Windows на порт80 внешней VM. Прямой адрес в сети стенда - `http://172.27.25.1/zabbix/`.

## Запуск

1. В PowerShell Windows запустить внешнюю VM и проверить ее состояние:

```powershell
& 'C:\Program Files\Oracle\VirtualBox\VBoxManage.exe' startvm 'Matvey_Lab4_Debian_20261027' --type headless
& 'C:\Program Files\Oracle\VirtualBox\VBoxManage.exe' showvminfo 'Matvey_Lab4_Debian_20261027' --machinereadable
```

Если внешняя VM уже работает, повторно запускать ее не требуется. Дождаться загрузки Debian и доступности SSH.

2. Подключиться к внешней VM с имеющейся собственной учетной записью. Пароли и закрытые SSH-ключи в этот документ не включены:

```powershell
ssh -p 22227 matvey@127.0.0.1
```

3. Внутри внешней VM проверить и запустить вложенный АРМ:

```sh
hostname
VBoxManage list runningvms
VBoxManage startvm Matvey_Bridge_Debian_20261027 --type headless
```

Если вложенная VM уже работает, второй запуск не нужен. При ошибке `VERR_VMX_IN_VMX_ROOT_MODE` в этой выделенной Linux VM сначала проверить, что KVM/QEMU не использует другие VM:

```sh
pgrep -a -f 'qemu-system|qemu-kvm' || true
sudo fuser /dev/kvm || true
```

Только если обе проверки показывают отсутствие работающих KVM-гостей, освободить аппаратную виртуализацию и повторить запуск вложенной VirtualBox VM:

```sh
sudo modprobe -r kvm_intel kvm
VBoxManage startvm Matvey_Bridge_Debian_20261027 --type headless
```

4. Проверить сеть и службы на сервере:

```sh
ping -c 4 -W 2 172.27.25.2
systemctl is-active postgresql@17-main zabbix-server zabbix-agent nginx php8.4-fpm
systemctl is-enabled postgresql zabbix-server zabbix-agent nginx php8.4-fpm
pg_isready
zabbix_get -s 172.27.25.2 -k agent.ping
zabbix_get -s 172.27.25.2 -k agent.hostname
curl -s -o /dev/null -w 'HTTP %{http_code}\n' http://172.27.25.1/zabbix/
```

Ожидаемые значения: все рабочие службы `active`, автозагрузка `enabled`, PostgreSQL принимает соединения, `agent.ping` возвращает `1`, `agent.hostname` - `matvey-arm`, HTTP - `200` после конечного URL с завершающим `/`.

5. Открыть веб-интерфейс и проверить `Monitoring -> Hosts`, затем `Latest data` для `Zabbix Server Matvey` и `User ARM Matvey`. Для подтверждения дождаться свежих значений. Зелёный индикатор ZBX характеризует доступность агента; столбец Problems может отдельно содержать сработавшие триггеры.

## Корректная остановка

Сначала завершить работу АРМ, затем внешней VM. В терминале внешней Debian VM:

```sh
VBoxManage controlvm Matvey_Bridge_Debian_20261027 acpipowerbutton
VBoxManage list runningvms
```

Дождаться исчезновения АРМ из `list runningvms`, проверить `VMState="poweroff"` через `VBoxManage showvminfo ... --machinereadable`, затем завершить работу сервера:

```sh
sudo poweroff
```

В PowerShell Windows проверить завершение внешней VM:

```powershell
& 'C:\Program Files\Oracle\VirtualBox\VBoxManage.exe' list runningvms
& 'C:\Program Files\Oracle\VirtualBox\VBoxManage.exe' showvminfo 'Matvey_Lab4_Debian_20261027' --machinereadable
```

Принудительное `poweroff` через VBoxManage и удаление/восстановление снимка не входят в обычную остановку. Снимок `Before_Lab5_20261119` относится к состоянию до установки Zabbix; его восстановление отменит изменения ЛР5 и выполняется только как отдельная операция восстановления.

## Фактически установленные версии

- Windows VirtualBox: `7.2.20r175154`.
- Вложенный Linux VirtualBox: `7.2.22r175245`.
- Обе гостевые ОС: Debian GNU/Linux13, point release13.7 на момент проверки19.11.2026.
- Zabbix Server/Agent/frontend: `7.0.32`.
- PostgreSQL: кластер17.
- Nginx: пакет `1.26.3-3+deb13u10`.
- PHP-FPM/PHP-PgSQL: `8.4.27-1~deb13u1`.

Команды приведены для уже подготовленного локального стенда; повторная инициализация роли/базы PostgreSQL и импорт исходной схемы при каждом запуске не требуются.

## Сохраненное состояние после выполнения

После всех проверок 19.11.2026 АРМ завершён через ACPI, затем сервер завершён штатной командой systemctl poweroff. Обе VM находятся в состоянии poweroff. Готовая конфигурация сохранена в снимке внешней VM `Lab5_Zabbix_Ready_20261119` (UUID `f35eec9d-a4cf-4f1d-9340-b84412316471`). Для обычного запуска восстанавливать снимок не требуется: запускайте текущее состояние по инструкции выше. Скриншоты и протоколы отчёта относятся к проверке до выключения.
